document.addEventListener('mousemove', function(e) {
    var customCursor = document.querySelector('.custom-cursor');
    customCursor.style.left = e.pageX + 'px';
    customCursor.style.top = e.pageY + 'px';
  });
  document.addEventListener('mousedown', function(e) {
    var customCursor = document.querySelector('.custom-cursor');
    customCursor.classList.add('click');
  });
  document.addEventListener('mouseup', function(e) {
    var customCursor = document.querySelector('.custom-cursor');
    customCursor.classList.remove('click');
  })
  // var customCursor = document.querySelector('.custom-cursor');
  // customCursor.classList.add('click');
  // customCursor.classList.remove('click');
  